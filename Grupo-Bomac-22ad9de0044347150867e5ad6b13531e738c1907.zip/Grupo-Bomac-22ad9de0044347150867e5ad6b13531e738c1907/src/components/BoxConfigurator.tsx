import { useState } from 'react';
import { motion } from 'motion/react';
import { BoxConfig } from '../types';
import { Layers, Settings, Weight, Leaf, Euro, Info, Send, CornerDownRight } from 'lucide-react';

interface BoxConfiguratorProps {
  onApplySpecs: (specsText: string) => void;
}

export default function BoxConfigurator({ onApplySpecs }: BoxConfiguratorProps) {
  const [config, setConfig] = useState<BoxConfig>({
    length: 40,
    width: 30,
    height: 25,
    cardboardType: 'simple',
    quantity: 500
  });

  const [activeTab, setActiveTab] = useState<'3d' | 'plane'>('3d');
  const [flapAngle, setFlapAngle] = useState(15); // flap opening angle

  // Calculations
  const getGsm = (type: BoxConfig['cardboardType']) => {
    switch (type) {
      case 'micro': return 240;
      case 'simple': return 380;
      case 'double': return 650;
      case 'triple': return 980;
    }
  };

  const getTypeName = (type: BoxConfig['cardboardType']) => {
    switch (type) {
      case 'micro': return 'Microcorrugado (Onda E-F)';
      case 'simple': return 'Onda Simple (Flauta B-C)';
      case 'double': return 'Doble Ondulado (BC Alta Carga)';
      case 'triple': return 'Triple Canal (Húmedo Extremo)';
    }
  };

  const calculateSpecs = () => {
    const l = config.length;
    const w = config.width;
    const h = config.height;
    
    // Total cardboard flat sheet surface area (in m2) including tab flaps and margins
    const flatLength = (2 * l) + (2 * w) + 5; // +5cm joint glue flap
    const flatWidth = w + h + w; // flaps fold over depth
    const areaM2 = (flatLength * flatWidth) / 10000;
    
    const gsm = getGsm(config.cardboardType);
    const weightg = areaM2 * gsm;
    
    // CO2 savings compared to expanded polystyrene/bubble wrap of similar size (est. 0.04kg co2 / cm3)
    const carbonSavedKg = parseFloat(((l * w * h * 0.000045)).toFixed(2));
    
    // Pricing engine
    let basePricePerM2 = 1.65;
    if (config.cardboardType === 'micro') basePricePerM2 = 1.35;
    if (config.cardboardType === 'double') basePricePerM2 = 2.45;
    if (config.cardboardType === 'triple') basePricePerM2 = 3.95;
    
    const rawCost = areaM2 * basePricePerM2;
    
    // Bulk volume pricing adjustment
    let volumeDiscount = 1.0;
    if (config.quantity >= 500 && config.quantity < 1000) volumeDiscount = 0.88;
    else if (config.quantity >= 1000 && config.quantity < 2500) volumeDiscount = 0.78;
    else if (config.quantity >= 2500) volumeDiscount = 0.64;
    
    const finalUnitPrice = Math.max(0.25, parseFloat((rawCost * volumeDiscount).toFixed(2)));
    const totalPrice = Math.round(finalUnitPrice * config.quantity);

    return {
      areaM2: parseFloat(areaM2.toFixed(3)),
      weightGrams: Math.round(weightg),
      carbonSavedKg,
      unitPrice: finalUnitPrice,
      totalPrice
    };
  };

  const stats = calculateSpecs();

  // Coordinates calculation for isometric 3D projection
  // Scaling factors to fit in a 360x360 SVG viewbox
  const scale = Math.min(2.5, 140 / Math.max(config.length, config.width, config.height));
  const l_px = config.length * scale;
  const w_px = config.width * scale;
  const h_px = config.height * scale;

  const cx = 180;
  const cy = 230 + (h_px / 4); // anchor point

  // Isometric points
  const cos30 = 0.866;
  const sin30 = 0.500;

  // Bottom central corner (vertex closest to viewer)
  const p1_x = cx;
  const p1_y = cy;

  // Bottom left-most corner (Length vector goes up-left)
  const p3_x = cx - (l_px * cos30);
  const p3_y = cy - (l_px * sin30);

  // Bottom right-most corner (Width vector goes up-right)
  const p5_x = cx + (w_px * cos30);
  const p5_y = cy - (w_px * sin30);

  // Top central-front corner (Extruding straight upwards from P1)
  const p2_x = cx;
  const p2_y = cy - h_px;

  // Top left corner (Extruding straight up from P3)
  const p4_x = p3_x;
  const p4_y = p3_y - h_px;

  // Top right corner (Extruding straight up from P5)
  const p6_x = p5_x;
  const p6_y = p5_y - h_px;

  // Top back central corner (Intersection point)
  const p7_x = cx - (l_px * cos30) + (w_px * cos30);
  const p7_y = cy - (l_px * sin30) - (w_px * sin30) - h_px;

  // Open flap geometries (top panels)
  // Angle flap open calculation
  const flapRad = (flapAngle * Math.PI) / 180;
  
  // Left side top flap (hinged along P4-P2)
  const f_l_x = p4_x + (w_px / 2 * cos30 * Math.cos(flapRad));
  const f_l_y = p4_y - (w_px / 2 * sin30) - (w_px / 2 * Math.sin(flapRad));
  const f_r_x = p2_x + (w_px / 2 * cos30 * Math.cos(flapRad));
  const f_r_y = p2_y - (w_px / 2 * sin30) - (w_px / 2 * Math.sin(flapRad));

  // Trigger contact transfer
  const handleTransferToContact = () => {
    const specsText = `Pre-cotización de Caja Personalizada:
Dimensiones: ${config.length} x ${config.width} x ${config.height} cm (Base x Profundidad x Altura)
Grosor: ${getTypeName(config.cardboardType)}
Cantidad Solicitada: ${config.quantity} unidades
Est. Peso Unitario: ${stats.weightGrams}g, Área: ${stats.areaM2} m²
Ahorro de Carbono: ~${stats.carbonSavedKg} kg CO2eq
Precio Unitario Estimado: €${stats.unitPrice} / Precio Total Estimado: €${stats.totalPrice}`;

    onApplySpecs(specsText);
  };

  return (
    <section id="configurador" className="py-24 bg-brand-beige-container border-y border-brand-charcoal/10 paper-grain relative">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Title Block */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="font-mono text-xs tracking-widest font-extrabold text-brand-sage uppercase block mb-3">
            Herramienta Interactiva
          </span>
          <h2 className="font-sans text-3xl md:text-5xl font-extrabold tracking-tight text-brand-charcoal mb-4">
            Configurador de Empaque Industrial
          </h2>
          <p className="font-sans text-sm text-brand-sage leading-relaxed">
            Ajuste el cubicaje y calibre de su embalaje en tiempo real. Obtenga mermas volumétricas automatizadas y su impacto sustentable de inmediato.
          </p>
        </div>

        {/* Dynamic Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          
          {/* Controls Column (Left) - 5 Cols */}
          <div className="lg:col-span-5 space-y-6 bg-brand-beige-light p-6 md:p-8 rounded-lg border border-brand-charcoal/5">
            <div className="flex items-center gap-2 mb-2 pb-4 border-b border-brand-charcoal/5">
              <Settings className="w-5 h-5 text-brand-olive" />
              <h3 className="font-sans text-base font-bold text-brand-charcoal uppercase tracking-wider">
                Parámetros Especiales
              </h3>
            </div>

            {/* Dimension Sliders */}
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-xs font-bold text-brand-sage mb-1.5 uppercase">
                  <span>Largo (L): {config.length} cm</span>
                  <span className="text-brand-brown">Línea Base</span>
                </div>
                <input
                  type="range"
                  min="15"
                  max="120"
                  value={config.length}
                  onChange={(e) => setConfig({ ...config, length: parseInt(e.target.value) })}
                  className="w-full accent-brand-olive h-1.5 bg-brand-charcoal/10 rounded-sm cursor-col-resize"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs font-bold text-brand-sage mb-1.5 uppercase">
                  <span>Ancho (W): {config.width} cm</span>
                  <span className="text-brand-brown">Profundidad</span>
                </div>
                <input
                  type="range"
                  min="15"
                  max="100"
                  value={config.width}
                  onChange={(e) => setConfig({ ...config, width: parseInt(e.target.value) })}
                  className="w-full accent-brand-olive h-1.5 bg-brand-charcoal/10 rounded-sm cursor-col-resize"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs font-bold text-brand-sage mb-1.5 uppercase">
                  <span>Alto (H): {config.height} cm</span>
                  <span className="text-brand-brown">Altura Vertical</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="80"
                  value={config.height}
                  onChange={(e) => setConfig({ ...config, height: parseInt(e.target.value) })}
                  className="w-full accent-brand-olive h-1.5 bg-brand-charcoal/10 rounded-sm cursor-col-resize"
                />
              </div>
            </div>

            {/* Board Type Selection */}
            <div className="space-y-3 pt-2">
              <label className="block text-xs font-bold text-brand-sage uppercase tracking-wider">
                Espesor Flauta & Rigidez del Cartón
              </label>
              <div className="grid grid-cols-2 gap-2">
                {(['micro', 'simple', 'double', 'triple'] as const).map((type) => (
                  <button
                    key={type}
                    onClick={() => setConfig({ ...config, cardboardType: type })}
                    className={`p-3 text-[11px] font-bold text-left rounded-sm border uppercase transition-all ${
                      config.cardboardType === type
                        ? 'border-brand-olive bg-brand-olive/5 text-brand-olive font-extrabold'
                        : 'border-brand-charcoal/10 text-brand-sage hover:bg-brand-beige'
                    }`}
                  >
                    <span className="block font-sans text-xs">{type === 'micro' ? 'Micro' : type === 'simple' ? 'Simple' : type === 'double' ? 'Doble' : 'Triple'}</span>
                    <span className="block text-[8px] opacity-75 font-mono mt-0.5">{getGsm(type)} g/m²</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity Slider */}
            <div className="pt-2">
              <div className="flex justify-between text-xs font-bold text-brand-sage mb-1.5 uppercase">
                <span>Volumen: {config.quantity.toLocaleString()} unidades</span>
                <span className="text-brand-olive">Escala Industrial</span>
              </div>
              <input
                type="range"
                min="100"
                max="5000"
                step="50"
                value={config.quantity}
                onChange={(e) => setConfig({ ...config, quantity: parseInt(e.target.value) })}
                className="w-full accent-brand-olive h-1.5 bg-brand-charcoal/10 rounded-sm cursor-col-resize"
              />
              <span className="text-[10px] text-brand-sage block mt-1.5 font-mono italic">
                * Descuento volumétrico del {config.quantity >= 2500 ? '36%' : config.quantity >= 1000 ? '22%' : config.quantity >= 500 ? '12%' : '0%'} aplicado automáticamente.
              </span>
            </div>

            {/* Dynamic Flap control inside 3D */}
            {activeTab === '3d' && (
              <div className="pt-1">
                <div className="flex justify-between text-[11px] font-bold text-brand-sage mb-1 uppercase">
                  <span>Simulador de Flaps: {flapAngle}° (Humedad)</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="90"
                  value={flapAngle}
                  onChange={(e) => setFlapAngle(parseInt(e.target.value))}
                  className="w-full accent-brand-brown h-1 bg-brand-charcoal/5 rounded-sm"
                />
              </div>
            )}
          </div>

          {/* Interactive Viewer Column (Middle) - 7 Cols */}
          <div className="lg:col-span-12 xl:col-span-7 flex flex-col justify-between">
            <div className="bg-brand-beige-light border border-brand-charcoal/5 rounded-lg overflow-hidden flex-1 flex flex-col min-h-[420px]">
              
              {/* Viewer Mode Tabs Header */}
              <div className="flex border-b border-brand-charcoal/5 bg-brand-beige/50 p-2 gap-2">
                <button
                  onClick={() => setActiveTab('3d')}
                  className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-sm transition-all cursor-pointer ${
                    activeTab === '3d'
                      ? 'bg-brand-olive text-brand-beige'
                      : 'text-brand-sage hover:text-brand-charcoal'
                  }`}
                >
                  Vista Isométrica 3D
                </button>
                <button
                  onClick={() => setActiveTab('plane')}
                  className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-sm transition-all cursor-pointer ${
                    activeTab === 'plane'
                      ? 'bg-brand-olive text-brand-beige'
                      : 'text-brand-sage hover:text-brand-charcoal'
                  }`}
                >
                  Plano de Desplante 2D (Troquel)
                </button>
              </div>

              {/* Main SVG Container */}
              <div className="flex-1 flex items-center justify-center p-6 bg-brand-beige-container/30 relative">
                
                {/* 3D Isometric SVG Model */}
                {activeTab === '3d' && (
                  <svg
                    viewBox="0 0 360 360"
                    className="w-full max-w-[340px] drop-shadow-[0_20px_50px_rgba(139,69,19,0.04)]"
                    height="100%"
                  >
                    {/* Shadow underneath */}
                    <ellipse
                      cx="180"
                      cy={cy + 10}
                      rx={Math.max(40, (l_px + w_px) * 0.75)}
                      ry={Math.max(15, (l_px + w_px) * 0.25)}
                      fill="rgba(123, 57, 6, 0.08)"
                      filter="blur(10px)"
                    />

                    {/* Right vertical face shadow backdrop */}
                    {/* Left vertical plane */}
                    <polygon
                      points={`${p1_x},${p1_y} ${p3_x},${p3_y} ${p4_x},${p4_y} ${p2_x},${p2_y}`}
                      fill="#dacbae"
                      stroke="#8c7c64"
                      strokeWidth="1.5"
                      strokeLinejoin="round"
                    />

                    {/* Right vertical plane */}
                    <polygon
                      points={`${p1_x},${p1_y} ${p5_x},${p5_y} ${p6_x},${p6_y} ${p2_x},${p2_y}`}
                      fill="#ccbca0"
                      stroke="#8c7c64"
                      strokeWidth="1.5"
                      strokeLinejoin="round"
                    />

                    {/* Standard top plane or open flaps projection */}
                    {flapAngle === 0 ? (
                      // Closed top lid
                      <polygon
                        points={`${p2_x},${p2_y} ${p4_x},${p4_y} ${p7_x},${p7_y} ${p6_x},${p6_y}`}
                        fill="#efe6d5"
                        stroke="#8c7c64"
                        strokeWidth="1.5"
                        strokeLinejoin="round"
                      />
                    ) : (
                      // Interactively Opened Flaps representation
                      <>
                        {/* Shadow cavity inside the box */}
                        <polygon
                          points={`${p2_x},${p2_y} ${p4_x},${p4_y} ${p7_x},${p7_y} ${p6_x},${p6_y}`}
                          fill="#6e5d47"
                          stroke="#4a3e2e"
                          strokeWidth="1.5"
                        />

                        {/* Right flap folding outwards along P2-P6 */}
                        <polygon
                          points={`
                            ${p2_x},${p2_y} 
                            ${p6_x},${p6_y} 
                            ${p6_x + (l_px/2 * cos30 * Math.cos((flapAngle*Math.PI)/180))},${p6_y - (l_px/2 * sin30) - (l_px/2 * Math.sin((flapAngle*Math.PI)/180))}
                            ${p2_x + (l_px/2 * cos30 * Math.cos((flapAngle*Math.PI)/180))},${p2_y - (l_px/2 * sin30) - (l_px/2 * Math.sin((flapAngle*Math.PI)/180))}
                          `}
                          fill="#decfae"
                          stroke="#8c7c64"
                          strokeWidth="1"
                        />

                        {/* Left flap folding outwards along P4-P2 */}
                        <polygon
                          points={`
                            ${p4_x},${p4_y} 
                            ${p2_x},${p2_y} 
                            ${f_r_x},${f_r_y}
                            ${f_l_x},${f_l_y}
                          `}
                          fill="#e9dfcc"
                          stroke="#8c7c64"
                          strokeWidth="1"
                        />
                      </>
                    )}

                    {/* Blueprints / Engineering dimensional markers overlay in vector lines */}
                    <line x1={p3_x - 15} y1={p3_y} x2={p1_x - 15} y2={p1_y} stroke="#7b3906" strokeWidth="1" strokeDasharray="3,3" />
                    <text x={(p3_x + p1_x)/2 - 15} y={(p3_y + p1_y)/2 + 20} className="font-mono text-[9px] fill-brand-brown font-bold text-center">
                      L: {config.length}cm
                    </text>

                    <line x1={p1_x + 15} y1={p1_y} x2={p5_x + 15} y2={p5_y} stroke="#7b3906" strokeWidth="1" strokeDasharray="3,3" />
                    <text x={(p1_x + p5_x)/2 + 25} y={(p1_y + p5_y)/2 + 20} className="font-mono text-[9px] fill-brand-brown font-bold text-center">
                      W: {config.width}cm
                    </text>

                    <line x1={p5_x + 20} y1={p5_y} x2={p6_x + 20} y2={p6_y} stroke="#7b3906" strokeWidth="1" strokeDasharray="3,3" />
                    <text x={p5_x + 35} y={(p5_y + p6_y)/2} className="font-mono text-[9px] fill-brand-brown font-bold">
                      H: {config.height}cm
                    </text>
                  </svg>
                )}

                {/* 2D Flat Blueprint SVG troquel */}
                {activeTab === 'plane' && (
                  <svg
                    viewBox="0 0 360 280"
                    className="w-full max-w-[340px]"
                    height="100%"
                  >
                    {/* Outline box drawing standard unfolded Corrugated cardboard box blueprint */}
                    {/* Top Flap */}
                    <rect x="70" y="50" width="60" height="40" fill="none" stroke="#1b1c1c" strokeWidth="1.5" />
                    <rect x="130" y="50" width="100" height="40" fill="none" stroke="#1b1c1c" strokeWidth="1.5" />
                    <rect x="230" y="50" width="60" height="40" fill="none" stroke="#1b1c1c" strokeWidth="1.5" />
                    
                    {/* Main Middle Panels with fold dashlines in Saddle Brown red */}
                    <rect x="70" y="90" width="60" height="100" fill="none" stroke="#1b1c1c" strokeWidth="1.5" />
                    <rect x="130" y="90" width="100" height="100" fill="none" stroke="#1b1c1c" strokeWidth="1.5" />
                    <rect x="230" y="90" width="60" height="100" fill="none" stroke="#1b1c1c" strokeWidth="1.5" strokeDasharray="" />
                    
                    {/* Glue joint horizontal flap */}
                    <polygon points="290,90 300,98 300,182 290,190" fill="none" stroke="#1b1c1c" strokeWidth="1.5" />

                    {/* Bottom Flaps */}
                    <rect x="70" y="190" width="60" height="40" fill="none" stroke="#1b1c1c" strokeWidth="1.5" />
                    <rect x="130" y="190" width="100" height="40" fill="none" stroke="#1b1c1c" strokeWidth="1.5" />
                    <rect x="230" y="190" width="60" height="40" fill="none" stroke="#1b1c1c" strokeWidth="1.5" />

                    {/* Fold Indicator lines in red/brown */}
                    <line x1="70" y1="90" x2="290" y2="90" stroke="#7b3906" strokeWidth="1" strokeDasharray="4,2" />
                    <line x1="70" y1="190" x2="290" y2="190" stroke="#7b3906" strokeWidth="1" strokeDasharray="4,2" />
                    <line x1="130" y1="90" x2="130" y2="190" stroke="#7b3906" strokeWidth="1" strokeDasharray="4,2" />
                    <line x1="230" y1="90" x2="230" y2="190" stroke="#7b3906" strokeWidth="1" strokeDasharray="4,2" />

                    {/* Blueprint annotations */}
                    <text x="180" y="145" className="font-sans text-[11px] font-bold fill-brand-olive text-center" textAnchor="middle">
                      Cuerpo Central
                    </text>
                    <text x="13" y="140" className="font-mono text-[9px] fill-brand-brown" transform="rotate(-90 13 140)">
                      Despliegue: {(config.width * 2 + config.height).toFixed(0)}cm
                    </text>
                    <text x="180" y="270" className="font-mono text-[9px] fill-brand-brown" textAnchor="middle">
                      Largo Troquel: {(config.length * 2 + config.width * 2 + 5).toFixed(0)}cm
                    </text>
                  </svg>
                )}

                {/* Micro badge indicator */}
                <div className="absolute right-4 bottom-4 bg-brand-charcoal text-brand-beige px-2 py-1 text-[9px] font-mono rounded tracking-widest uppercase">
                  Escala Virtual
                </div>
              </div>

              {/* Instant Real-Time Stats Grid */}
              <div className="bg-brand-beige-container border-t border-brand-charcoal/5 grid grid-cols-2 md:grid-cols-4 p-4 gap-4 text-center">
                
                <div className="p-2">
                  <span className="flex items-center justify-center gap-1.5 font-sans text-[10px] font-bold text-brand-sage uppercase mb-1">
                    <Weight className="w-3.5 h-3.5 text-brand-olive" />
                    Peso Unidad
                  </span>
                  <span className="block font-mono text-base font-extrabold text-brand-charcoal">
                    {stats.weightGrams}g
                  </span>
                </div>

                <div className="p-2 border-l border-brand-charcoal/10 md:border-l">
                  <span className="flex items-center justify-center gap-1.5 font-sans text-[10px] font-bold text-brand-sage uppercase mb-1">
                    <Leaf className="w-3.5 h-3.5 text-brand-olive" />
                    Ahorro CO2eq
                  </span>
                  <span className="block font-sans text-base font-extrabold text-brand-olive">
                    ~{stats.carbonSavedKg} kg
                  </span>
                </div>

                <div className="p-2 border-l border-brand-charcoal/10">
                  <span className="flex items-center justify-center gap-1.5 font-sans text-[10px] font-bold text-brand-sage uppercase mb-1">
                    <Euro className="w-3.5 h-3.5 text-brand-brown" />
                    Unitario Est.
                  </span>
                  <span className="block font-mono text-base font-extrabold text-brand-charcoal">
                    €{stats.unitPrice}
                  </span>
                </div>

                <div className="p-2 border-l border-brand-charcoal/10">
                  <span className="flex items-center justify-center gap-1.5 font-sans text-[10px] font-bold text-brand-sage uppercase mb-1">
                    <Layers className="w-3.5 h-3.5 text-brand-brown" />
                    Total Lote
                  </span>
                  <span className="block font-mono text-base font-extrabold text-brand-charcoal">
                    €{stats.totalPrice.toLocaleString()}
                  </span>
                </div>

              </div>

            </div>

            {/* Direct CTA Transfer Module */}
            <div className="mt-4 bg-brand-brown/5 border border-brand-brown/15 p-4 rounded-sm flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex gap-2.5">
                <Info className="w-5 h-5 text-brand-brown shrink-0 mt-0.5" />
                <div className="text-left">
                  <span className="block font-sans text-xs font-bold text-brand-charcoal">¿Satisfecho con las tolerancias estructurales?</span>
                  <span className="block font-sans text-[11px] text-brand-sage">Transfiera los parámetros de volumen y gramaje directamente para recibir un quote formal personalizado.</span>
                </div>
              </div>
              <button
                onClick={handleTransferToContact}
                className="w-full md:w-auto px-5 py-2.5 bg-brand-brown text-brand-beige hover:bg-brand-olive hover:text-brand-beige text-xs font-bold uppercase tracking-wider rounded-sm transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer shrink-0"
                id="btn-transfer-specs"
              >
                <span>Cotizar esta Caja</span>
                <Send className="w-3.5 h-3.5 inline-block" />
              </button>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
