import { useState, useEffect, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Building2, User, Phone, MessageSquare, ClipboardCheck, ArrowRight, ShieldAlert, Sparkles, X } from 'lucide-react';

interface ContactFormProps {
  attachedSpecs: string;
  onClearSpecs: () => void;
}

export default function ContactForm({ attachedSpecs, onClearSpecs }: ContactFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    phone: '',
    message: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState('');

  // Sync attached specs into the message field if they change
  useEffect(() => {
    if (attachedSpecs) {
      setFormData(prev => ({
        ...prev,
        message: prev.message 
          ? `${prev.message}\n\n---\n${attachedSpecs}` 
          : attachedSpecs
      }));
    }
  }, [attachedSpecs]);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      setError('Por favor complete los campos obligatorios: Nombre, Email y Mensaje.');
      return;
    }
    setError('');
    setIsSubmitting(true);

    // Simulate ecological calculation feedback delay
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 1500);
  };

  const handleReset = () => {
    setFormData({
      name: '',
      email: '',
      company: '',
      phone: '',
      message: ''
    });
    onClearSpecs();
    setIsSubmitted(false);
  };

  return (
    <section id="contacto" className="py-24 max-w-7xl mx-auto px-6 paper-grain relative">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        
        {/* Left Information Column (5/12) */}
        <div className="lg:col-span-5 space-y-8">
          <div>
            <span className="font-mono text-xs tracking-widest font-extrabold text-brand-sage uppercase block mb-3">
              Área de Contacto & Enlaces Directos
            </span>
            <h2 className="font-sans text-3xl md:text-5xl font-extrabold tracking-tight text-brand-charcoal mb-5">
              Hablemos de Ingeniería
            </h2>
            <p className="font-sans text-base text-brand-sage leading-relaxed">
              ¿Tiene requerimientos volumétricos complejos, condiciones climáticas demandantes en almacenamiento o metas urgentes de reducción de mermas plásticas? Nuestro laboratorio técnico está listo para analizar sus planos.
            </p>
          </div>

          {/* Quick Stats Grid */}
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-brand-beige-container border-l-2 border-brand-olive rounded-sm">
              <span className="block font-mono text-xl font-black text-brand-olive">&lt; 2 Horas</span>
              <span className="block font-sans text-xs text-brand-sage uppercase font-bold mt-1">Tiempo de Respuesta</span>
            </div>
            <div className="p-4 bg-brand-beige-container border-l-2 border-brand-brown rounded-sm">
              <span className="block font-mono text-xl font-black text-brand-brown">Gratuito</span>
              <span className="block font-sans text-xs text-brand-sage uppercase font-bold mt-1">Primer Prototipo Virtual</span>
            </div>
          </div>

          {/* Address and telephone specs */}
          <div className="space-y-4 pt-4 border-t border-brand-charcoal/10 font-mono text-xs text-brand-sage">
            <div>
              <span className="block font-sans font-bold uppercase text-brand-charcoal mb-1">Oficinas Centrales & Planta:</span>
              <span className="block">Polígono Industrial Cartografía Sostenible, Nave A, Madrid, España.</span>
            </div>
            <div>
              <span className="block font-sans font-bold uppercase text-brand-charcoal mb-1">Contacto Directo:</span>
              <a href="mailto:jhomardelgado@gmail.com" className="block text-brand-olive font-bold hover:underline">jhomardelgado@gmail.com</a>
              <a href="tel:+3490000000" className="block text-brand-charcoal mt-1">+34 900 000 000</a>
            </div>
            <div className="pt-2">
              <span className="inline-flex items-center gap-2 px-3 py-1 bg-brand-olive/10 text-brand-olive rounded-full font-bold uppercase text-[9px] tracking-wider">
                ● Atendiendo a nivel Global
              </span>
            </div>
          </div>
        </div>

        {/* Right Form Box Column (7/12) */}
        <div className="lg:col-span-7 bg-brand-beige-light border border-brand-charcoal/5 p-6 md:p-10 rounded-lg shadow-[0_12px_40px_rgba(62,82,25,0.02)]">
          <AnimatePresence mode="wait">
            {!isSubmitted ? (
              <motion.form
                key="form-contact"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                onSubmit={handleSubmit}
                className="space-y-6 text-left"
                id="contact-form-element"
              >
                <div className="pb-3 border-b border-brand-charcoal/5 flex items-center justify-between">
                  <h3 className="font-sans text-lg font-bold text-brand-charcoal uppercase tracking-wider">
                    Formulario de Solicitud Óptima
                  </h3>
                  <span className="font-mono text-xs text-brand-sage">* Requerido</span>
                </div>

                {/* Specs Attachment Alert Layer */}
                {attachedSpecs && (
                  <motion.div
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="p-4 bg-brand-olive/5 border border-brand-olive/15 rounded-sm flex items-start justify-between gap-3"
                  >
                    <div className="flex gap-2.5">
                      <ClipboardCheck className="w-5 h-5 text-brand-olive shrink-0 mt-0.5" />
                      <div>
                        <span className="block font-sans text-xs font-black text-brand-olive uppercase tracking-wider flex items-center gap-1.5">
                          <Sparkles className="w-3.5 h-3.5" />
                          Especificación de Caja Vinculada
                        </span>
                        <span className="block font-sans text-[11px] text-brand-sage mt-0.5">
                          Hemos cargado de forma inteligente las tolerancias, el volumen solicitado, el gramaje y el cubicaje de la simulación.
                        </span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={onClearSpecs}
                      className="text-brand-sage hover:text-brand-brown p-1 transition-colors rounded hover:bg-brand-brown/5 cursor-pointer"
                      title="Quitar especificaciones vinculadas"
                      id="btn-clear-inline-specs"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </motion.div>
                )}

                {/* Normal Input Fields Row */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  
                  {/* Name */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono font-bold text-brand-sage uppercase tracking-wider flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-brand-olive" />
                      Nombre y Apellidos *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Ej. Juan Pérez"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-3 bg-brand-beige-container/30 border border-brand-charcoal/10 rounded-sm font-sans text-sm focus:outline-none focus:border-brand-olive transition-colors"
                    />
                  </div>

                  {/* Email */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono font-bold text-brand-sage uppercase tracking-wider flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-brand-olive" />
                      Correo Electrónico *
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="correo@empresa.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-3 bg-brand-beige-container/30 border border-brand-charcoal/10 rounded-sm font-sans text-sm focus:outline-none focus:border-brand-olive transition-colors"
                    />
                  </div>

                  {/* Company */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono font-bold text-brand-sage uppercase tracking-wider flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-brand-olive" />
                      Empresa / Corporación
                    </label>
                    <input
                      type="text"
                      placeholder="Nombre de su Empresa"
                      value={formData.company}
                      onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                      className="w-full px-4 py-3 bg-brand-beige-container/30 border border-brand-charcoal/10 rounded-sm font-sans text-sm focus:outline-none focus:border-brand-olive transition-colors"
                    />
                  </div>

                  {/* Phone */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono font-bold text-brand-sage uppercase tracking-wider flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-brand-olive" />
                      Teléfono de Contacto
                    </label>
                    <input
                      type="tel"
                      placeholder="+34 600 000 000"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-4 py-3 bg-brand-beige-container/30 border border-brand-charcoal/10 rounded-sm font-sans text-sm focus:outline-none focus:border-brand-olive transition-colors"
                    />
                  </div>

                </div>

                {/* Message detail */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono font-bold text-brand-sage uppercase tracking-wider flex items-center gap-1.5">
                    <MessageSquare className="w-3.5 h-3.5 text-brand-olive" />
                    Especificación Técnica o Mensaje *
                  </label>
                  <textarea
                    required
                    rows={6}
                    placeholder="Describa el producto a empacar, peso de estiba, o condiciones térmicas que requiere..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full px-4 py-3 bg-brand-beige-container/30 border border-brand-charcoal/10 rounded-sm font-sans text-sm focus:outline-none focus:border-brand-olive transition-colors resize-y min-h-[120px]"
                  />
                </div>

                {/* Error handling */}
                {error && (
                  <div className="p-3 bg-brand-brown-light text-brand-brown text-xs rounded-sm flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* CTA Action button client submission */}
                <div className="pt-2 text-right">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full px-6 py-4 bg-brand-olive hover:bg-brand-olive-light disabled:bg-brand-olive/50 text-brand-beige font-bold text-xs uppercase tracking-widest rounded-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
                    id="submit-contact-button"
                  >
                    <span>{isSubmitting ? 'Procesando Simulación Estructural...' : 'Confirmar & Solicitar Asesoría'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </motion.form>
            ) : (
              // Success folding paper envelope animation card
              <motion.div
                key="success-card"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="py-12 px-6 text-center space-y-6 flex flex-col items-center justify-center min-h-[400px]"
                id="success-envelope"
              >
                {/* SVG representation of flat sheet folding into delivery box */}
                <div className="w-24 h-24 bg-brand-olive/10 rounded-lg flex items-center justify-center text-brand-olive mb-2 relative">
                  <motion.div
                    animate={{ rotateY: 360 }}
                    transition={{ repeat: Infinity, duration: 4, ease: 'linear' }}
                    className="absolute"
                  >
                    📦
                  </motion.div>
                </div>

                <h3 className="font-sans text-2xl font-black text-brand-olive uppercase tracking-tight">
                  ¡Ficha Recibida Exitosamente!
                </h3>
                
                <p className="font-sans text-sm text-brand-sage max-w-md leading-relaxed">
                  Hola <strong className="text-brand-charcoal">{formData.name}</strong>, gracias por contactar con Ingeniería en Papel. Hemost registrado tu requerimiento de la empresa <span className="text-brand-charcoal italic">{formData.company || 'Particular'}</span>. El prototipo virtual adjunto ha sido enviado a nuestro laboratorio de pruebas de fuerzas.
                </p>

                <div className="p-4 bg-brand-beige-container border border-brand-charcoal/5 rounded-sm max-w-md font-sans text-xs text-brand-sage leading-normal">
                  <span className="font-bold block text-brand-charcoal uppercase tracking-wider mb-1">Próximos Pasos:</span>
                  <span>1. Un diseñador estructural repasará la tolerancia de estiba.</span>
                  <span className="block">2. Te enviaremos un PDF técnico del troquel y presupuesto formal en menos de 2 horas.</span>
                </div>

                <button
                  type="button"
                  onClick={handleReset}
                  className="px-6 py-2.5 border border-brand-charcoal/20 text-brand-charcoal hover:border-brand-olive hover:text-brand-olive text-xs font-bold uppercase tracking-wider rounded-sm transition-colors cursor-pointer"
                  id="btn-re-estimate"
                >
                  Nueva Simulación de Caja
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

      </div>
    </section>
  );
}
