import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Layers, Menu, X, Phone, ArrowUpRight, Award } from 'lucide-react';

interface HeaderProps {
  onContactClick: () => void;
  onExploreClick: () => void;
  onSimulatorClick: () => void;
}

export default function Header({ onContactClick, onExploreClick, onSimulatorClick }: HeaderProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <>
      <motion.header
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
          scrolled 
            ? 'bg-brand-beige/95 backdrop-blur-md border-b border-brand-charcoal/10 py-3 shadow-[0_4px_30px_rgba(27,28,28,0.02)]' 
            : 'bg-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          {/* Logo */}
          <button 
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="flex items-center gap-3 group cursor-pointer text-left"
            id="logo-button"
          >
            <div className="w-10 h-10 bg-brand-olive flex items-center justify-center rounded-sm transition-transform duration-300 group-hover:rotate-12">
              <Layers className="text-brand-beige w-5.5 h-5.5" />
            </div>
            <div>
              <span className="block font-sans text-xs tracking-widest font-bold text-brand-olive uppercase leading-none">
                Ingeniería
              </span>
              <span className="block font-sans text-md tracking-normal font-extrabold text-brand-charcoal leading-tight">
                EN PAPEL
              </span>
            </div>
          </button>

          {/* Navigation Links - Desktop */}
          <nav className="hidden md:flex items-center gap-8">
            <button 
              onClick={onExploreClick}
              className="font-sans text-sm font-semibold text-brand-charcoal hover:text-brand-olive transition-colors duration-200 cursor-pointer"
            >
              Catálogo
            </button>
            <button 
              onClick={onSimulatorClick}
              className="font-sans text-sm font-semibold text-brand-charcoal hover:text-brand-olive transition-colors duration-200 cursor-pointer flex items-center gap-1"
            >
              Simulador 3D
              <span className="text-[10px] bg-brand-brown/10 text-brand-brown px-1.5 py-0.5 rounded-sm font-bold uppercase tracking-wider">Muestra</span>
            </button>
            <button 
              onClick={() => scrollToSection('compromiso')}
              className="font-sans text-sm font-semibold text-brand-charcoal hover:text-brand-olive transition-colors duration-200 cursor-pointer"
            >
              Sustentabilidad
            </button>
            <button 
              onClick={() => scrollToSection('metodo')}
              className="font-sans text-sm font-semibold text-brand-charcoal hover:text-brand-olive transition-colors duration-200 cursor-pointer"
            >
              Nuestra Ingeniería
            </button>
          </nav>

          {/* Action Buttons - Desktop */}
          <div className="hidden md:flex items-center gap-4">
            <a 
              href="tel:+3490000000" 
              className="font-mono text-xs text-brand-sage hover:text-brand-olive transition-colors duration-200 flex items-center gap-1.5"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>+34 900 000 000</span>
            </a>
            <button
              onClick={onContactClick}
              className="px-4 py-2 bg-brand-olive text-brand-beige hover:bg-brand-olive-light text-xs font-bold uppercase tracking-wider rounded-sm transition-all duration-200 cursor-pointer flex items-center gap-1"
              id="cta-contact-header"
            >
              Contactar
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 md:hidden text-brand-charcoal hover:text-brand-olive transition-colors"
            aria-label="Toggle menu"
            id="mobile-menu-toggle"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </motion.header>

      {/* Mobile Drawer Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="fixed top-[58px] left-0 w-full bg-brand-beige border-b border-brand-charcoal/10 shadow-lg z-40 md:hidden paper-grain"
          >
            <div className="p-6 flex flex-col gap-5">
              <button
                onClick={onExploreClick}
                className="w-full text-left font-sans text-base font-bold text-brand-charcoal py-2 border-b border-brand-charcoal/5 flex justify-between items-center"
              >
                <span>Catálogo de Productos</span>
                <span className="text-xs text-brand-sage">Ver Fichas</span>
              </button>
              <button
                onClick={onSimulatorClick}
                className="w-full text-left font-sans text-base font-bold text-brand-charcoal py-2 border-b border-brand-charcoal/5 flex justify-between items-center"
              >
                <span>Simulador de Caja 3D</span>
                <span className="px-1.5 py-0.5 bg-brand-brown-light text-brand-brown text-[9px] uppercase font-mono rounded">Interactiva</span>
              </button>
              <button
                onClick={() => scrollToSection('compromiso')}
                className="w-full text-left font-sans text-base font-bold text-brand-charcoal py-2 border-b border-brand-charcoal/5"
              >
                Compromiso Circular
              </button>
              <button
                onClick={() => scrollToSection('metodo')}
                className="w-full text-left font-sans text-base font-bold text-brand-charcoal py-2 border-b border-brand-charcoal/5"
              >
                Método de Pruebas
              </button>
              <div className="flex flex-col gap-4 mt-2">
                <a 
                  href="tel:+3490000000" 
                  className="font-mono text-sm text-brand-sage flex items-center gap-2 "
                >
                  <Phone className="w-4 h-4 text-brand-olive" />
                  <span>+34 900 000 000</span>
                </a>
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onContactClick();
                  }}
                  className="w-full py-3 bg-brand-olive text-brand-beige text-xs font-bold uppercase tracking-wider text-center rounded-sm"
                >
                  Solicitar Asesoría Técnica
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
