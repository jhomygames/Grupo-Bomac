import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, CheckCircle2, ShieldCheck, ArrowRight, Award } from 'lucide-react';
import { Product } from '../types';
import { PRODUCTS } from '../data';

interface ProductCatalogProps {
  onQuoteRequested: (productTitle: string) => void;
}

export default function ProductCatalog({ onQuoteRequested }: ProductCatalogProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0); // -1 for left, 1 for right

  const slideNext = () => {
    setDirection(1);
    setCurrentIndex((prev) => (prev + 1) % PRODUCTS.length);
  };

  const slidePrev = () => {
    setDirection(-1);
    setCurrentIndex((prev) => (prev - 1 + PRODUCTS.length) % PRODUCTS.length);
  };

  const currentProduct = PRODUCTS[currentIndex];

  const slideVariants = {
    enter: (dir: number) => ({
      x: dir > 0 ? '100%' : '-100%',
      opacity: 0,
    }),
    center: {
      x: 0,
      opacity: 1,
      transition: {
        x: { type: 'spring', stiffness: 300, damping: 30 },
        opacity: { duration: 0.3 }
      }
    },
    exit: (dir: number) => ({
      x: dir < 0 ? '100%' : '-100%',
      opacity: 0,
      transition: {
        x: { type: 'spring', stiffness: 300, damping: 30 },
        opacity: { duration: 0.3 }
      }
    })
  };

  return (
    <section id="catalogo" className="py-24 max-w-7xl mx-auto px-6 paper-grain relative">
      {/* Catalog Header matching the image layout */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
        <div>
          <span className="font-mono text-xs tracking-widest font-extrabold text-brand-sage uppercase block mb-3">
            Catálogo de Productos
          </span>
          <h2 className="font-sans text-3xl md:text-4xl lg:text-5xl font-extrabold tracking-tight text-brand-charcoal max-w-2xl leading-tight">
            Ingeniería en Papel para un Futuro Circular
          </h2>
        </div>
        <p className="font-sans text-base text-brand-sage max-w-sm md:text-right leading-relaxed">
          Diseñamos soluciones que protegen tanto tu mercancía como nuestro ecosistema compartido.
        </p>
      </div>

      {/* Main Catalog Slider Wrapper */}
      <div className="relative bg-brand-beige-container border border-brand-charcoal/5 rounded-lg overflow-hidden min-h-[500px] flex flex-col justify-between">
        
        {/* Dynamic content area */}
        <div className="relative overflow-hidden flex-1 min-h-[450px]">
          <AnimatePresence initial={false} custom={direction} mode="wait">
            <motion.div
              key={currentProduct.id}
              custom={direction}
              variants={slideVariants}
              initial="enter"
              animate="center"
              exit="exit"
              className="absolute inset-0 grid grid-cols-1 lg:grid-cols-12 w-full h-full"
            >
              {/* Product Info Column - 6/12 on lg */}
              <div className="lg:col-span-6 p-8 md:p-12 lg:p-14 flex flex-col justify-between h-full bg-brand-beige-light">
                <div>
                  <div className="flex items-center gap-2 mb-4">
                    <span className="text-[10px] font-mono font-extrabold bg-brand-olive/10 text-brand-olive px-2.5 py-1 uppercase tracking-wider rounded-sm">
                      {currentProduct.category}
                    </span>
                    <span className="text-[10px] font-mono font-bold text-brand-brown opacity-80 flex items-center gap-1">
                      <Award className="w-3.5 h-3.5" />
                      {currentProduct.certification}
                    </span>
                  </div>

                  <h3 className="font-sans text-4xl lg:text-5xl font-extrabold text-brand-olive tracking-tight leading-none mb-6">
                    {currentProduct.title}
                  </h3>
                  
                  <p className="font-sans text-base font-semibold text-brand-charcoal/80 mb-6 leading-relaxed">
                    {currentProduct.subtitle}
                  </p>

                  <p className="font-sans text-sm text-brand-sage mb-8 leading-relaxed">
                    {currentProduct.description}
                  </p>

                  {/* Advantages tags */}
                  <div className="space-y-2 mb-8">
                    {currentProduct.advantages.map((adv, idx) => (
                      <div key={idx} className="flex items-center gap-2.5">
                        <CheckCircle2 className="w-4.5 h-4.5 text-brand-olive shrink-0" />
                        <span className="font-sans text-xs font-semibold text-brand-charcoal/90">{adv}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Primary Action Button inside catalog item */}
                <div>
                  <button
                    onClick={() => onQuoteRequested(currentProduct.title)}
                    className="px-6 py-3 bg-brand-olive text-brand-beige hover:bg-brand-olive-light text-xs font-bold uppercase tracking-wider rounded-sm transition-colors duration-200 cursor-pointer flex items-center gap-2"
                    id={`btn-explore-${currentProduct.id}`}
                  >
                    <span>Explorar Más & Cotizar</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Product Material Art Showcase - 6/12 on lg */}
              <div className="lg:col-span-6 relative bg-brand-beige-container h-[250px] lg:h-full min-h-[300px]">
                {/* Background material representation with high res images */}
                <img
                  src={currentProduct.image}
                  alt={currentProduct.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center relative z-0 transition-all duration-700 hover:scale-105"
                />
                
                {/* Overlay Spec Grid HUD inside the asset */}
                <div className="absolute inset-x-4 bottom-4 grid grid-cols-2 gap-3 z-20">
                  {currentProduct.specs.map((spec, sIdx) => (
                    <motion.div
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.1 * sIdx, duration: 0.4 }}
                      key={sIdx}
                      className="bg-brand-beige/90 backdrop-blur-md border border-brand-charcoal/5 p-3 rounded-sm"
                    >
                      <span className="block font-sans text-[10px] font-bold text-brand-sage uppercase tracking-wider">
                        {spec.label}
                      </span>
                      <span className="block font-mono text-sm font-extrabold text-brand-charcoal mt-1">
                        {spec.value}
                      </span>
                    </motion.div>
                  ))}
                </div>

                {/* Left accent graphic element */}
                <div className="absolute inset-y-0 left-0 w-8 bg-gradient-to-r from-brand-beige-light/40 to-transparent pointer-events-none" />
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Navigation Controls matching the image footer layout */}
        <div className="bg-brand-beige-light border-t border-brand-charcoal/5 px-8 py-5 flex items-center justify-between">
          {/* Custom Arrows */}
          <div className="flex items-center gap-6">
            <button
              onClick={slidePrev}
              className="p-2 border border-brand-charcoal/10 hover:border-brand-olive text-brand-charcoal hover:bg-brand-beige hover:text-brand-olive rounded-sm transition-all duration-200 cursor-pointer"
              aria-label="Anterior"
              id="slider-control-prev"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={slideNext}
              className="p-2 border border-brand-charcoal/10 hover:border-brand-olive text-brand-charcoal hover:bg-brand-beige hover:text-brand-olive rounded-sm transition-all duration-200 cursor-pointer"
              aria-label="Siguiente"
              id="slider-control-next"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          {/* Dots Indicator */}
          <div className="flex items-center gap-2">
            {PRODUCTS.map((_, pIdx) => (
              <button
                key={pIdx}
                onClick={() => {
                  setDirection(pIdx > currentIndex ? 1 : -1);
                  setCurrentIndex(pIdx);
                }}
                className={`h-2 rounded-full transition-all duration-300 ${
                  pIdx === currentIndex ? 'w-8 bg-brand-olive' : 'w-2 bg-brand-charcoal/20 hover:bg-brand-charcoal/40'
                }`}
                aria-label={`Ir al producto ${pIdx + 1}`}
                id={`slider-dot-${pIdx}`}
              />
            ))}
          </div>

          {/* Technical Quality Indicator */}
          <div className="hidden sm:flex items-center gap-2 font-mono text-xs text-brand-sage">
            <ShieldCheck className="w-4 h-4 text-brand-olive" />
            <span>Verificación de Carga Homologada</span>
          </div>
        </div>

      </div>
    </section>
  );
}
