import { useState } from 'react';
import { motion } from 'motion/react';
import { 
  TreePine, 
  Leaf, 
  Sparkles, 
  CheckCircle, 
  Zap, 
  Layers, 
  Scale, 
  FileText, 
  ShieldCheck, 
  ArrowRight,
  ChevronDown
} from 'lucide-react';

import Header from './components/Header';
import ProductCatalog from './components/ProductCatalog';
import BoxConfigurator from './components/BoxConfigurator';
import ContactForm from './components/ContactForm';

import { CERTIFICATIONS, STEPS_WORKFLOW } from './data';

export default function App() {
  const [attachedSpecs, setAttachedSpecs] = useState<string>('');

  // Handle auto-populating specifications into contact form
  const handleApplySpecs = (specsText: string) => {
    setAttachedSpecs(specsText);
    
    // Smooth scroll down to the contact section
    const contactSection = document.getElementById('contacto');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  // Nav actions
  const scrollToId = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.15
      }
    }
  };

  const itemVariants = {
    hidden: { y: 30, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { type: 'spring', stiffness: 90, damping: 14 }
    }
  };

  return (
    <div className="bg-brand-beige min-h-screen relative paper-grain selection:bg-brand-olive/20 selection:text-brand-olive scroll-smooth">
      
      {/* Universal Floating Header */}
      <Header 
        onContactClick={() => scrollToId('contacto')}
        onExploreClick={() => scrollToId('catalogo')}
        onSimulatorClick={() => scrollToId('configurador')}
      />

      {/* Hero Section with high-end editorial and industrial layout */}
      <section className="relative pt-32 pb-24 md:pt-40 md:pb-36 overflow-hidden">
        
        {/* Subtle background industrial circles decoration */}
        <div className="absolute top-20 right-[-10%] w-[500px] h-[500px] rounded-full border border-brand-olive/10 pointer-events-none" />
        <div className="absolute bottom-10 left-[-10%] w-[350px] h-[350px] rounded-full border border-brand-brown/5 pointer-events-none" />

        <div className="max-w-7xl mx-auto px-6 text-center relative z-10">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="space-y-8"
          >
            {/* Top Tagline */}
            <motion.div variants={itemVariants} className="inline-flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-brand-olive rounded-full" />
              <span className="font-mono text-[10px] md:text-xs font-black text-brand-olive uppercase tracking-[0.2em]">
                Ingeniería Estructural Sostenible
              </span>
              <span className="w-1.5 h-1.5 bg-brand-olive rounded-full" />
            </motion.div>

            {/* Main Display Heading */}
            <motion.h1 
              variants={itemVariants}
              className="font-sans text-4xl md:text-6xl lg:text-7xl font-extrabold text-brand-charcoal tracking-tight max-w-5xl mx-auto leading-[0.95]"
            >
              Diseñamos la <span className="text-brand-olive">Resiliencia</span> del Empaque, Preservando la <span className="text-brand-brown font-serif italic font-normal">Pureza</span> del Bosque.
            </motion.h1>

            {/* Editorial Quote block using Accent Typography Playfair Italic */}
            <motion.p 
              variants={itemVariants}
              className="font-serif italic text-lg md:text-2xl text-brand-sage max-w-3xl mx-auto leading-relaxed"
            >
              "Un buen empaque no solo resiste la gravedad y el trayecto; honra al material primario que lo compone desde su origen forestal."
            </motion.p>

            {/* Quick value bullet indicators */}
            <motion.div 
              variants={itemVariants}
              className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto pt-4"
            >
              <div className="flex items-center justify-center gap-2 text-brand-charcoal">
                <CheckCircle className="w-4 h-4 text-brand-olive" />
                <span className="text-xs font-bold uppercase tracking-wider">Troqueles a Medida</span>
              </div>
              <div className="flex items-center justify-center gap-2 text-brand-charcoal">
                <CheckCircle className="w-4 h-4 text-brand-olive" />
                <span className="text-xs font-bold uppercase tracking-wider">FSC® Mixto Certificado</span>
              </div>
              <div className="flex items-center justify-center gap-2 text-brand-charcoal">
                <CheckCircle className="w-4 h-4 text-brand-olive" />
                <span className="text-xs font-bold uppercase tracking-wider">Ensayo BCT Homologado</span>
              </div>
              <div className="flex items-center justify-center gap-2 text-brand-charcoal">
                <CheckCircle className="w-4 h-4 text-brand-olive" />
                <span className="text-xs font-bold uppercase tracking-wider">Zero Adhesivos Tóxicos</span>
              </div>
            </motion.div>

            {/* Primary Action Buttons */}
            <motion.div 
              variants={itemVariants}
              className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-6"
            >
              <button
                onClick={() => scrollToId('configurador')}
                className="w-full sm:w-auto px-8 py-4 bg-brand-olive hover:bg-brand-olive-light text-brand-beige text-xs font-bold uppercase tracking-widest rounded-sm transition-all duration-300 shadow-md hover:shadow-lg cursor-pointer"
                id="hero-primary-cta"
              >
                Simulador de Caja 3D
              </button>
              <button
                onClick={() => scrollToId('catalogo')}
                className="w-full sm:w-auto px-8 py-4 border border-brand-charcoal text-brand-charcoal hover:bg-brand-charcoal hover:text-brand-beige text-xs font-bold uppercase tracking-widest rounded-sm transition-all duration-300 cursor-pointer"
              >
                Ver Catálogo de Productos
              </button>
            </motion.div>

            {/* Scroll Indicator Chevron */}
            <motion.div
              variants={itemVariants}
              animate={{ y: [0, 8, 0] }}
              transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
              className="pt-10 hidden md:block"
            >
              <button 
                onClick={() => scrollToId('compromiso')}
                className="text-brand-sage hover:text-brand-olive transition-colors cursor-pointer"
                aria-label="Desplazar hacia abajo"
              >
                <ChevronDown className="w-6 h-6 mx-auto" />
              </button>
            </motion.div>

          </motion.div>
        </div>
      </section>

      {/* Specialty Component: The Circular "Seal" / Commitment Segment */}
      <section id="compromiso" className="py-20 border-t border-brand-charcoal/10 relative overflow-hidden bg-brand-beige/50">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left panel text */}
          <div className="lg:col-span-7 space-y-6">
            <span className="font-mono text-xs tracking-widest font-extrabold text-brand-sage uppercase block">
              Nuestro Compromiso
            </span>
            <h2 className="font-sans text-3xl md:text-5xl font-extrabold tracking-tight text-brand-charcoal">
              Redefiniendo los Límites del Desecho
            </h2>
            <p className="font-sans text-base text-brand-sage leading-relaxed">
              En Ingeniería en Papel manufacturamos con un enfoque de bucle cerrado. Nos alejamos de los plásticos de un solo uso para ofrecer configuraciones de fibra natural con microcanales corrugados que otorgan el mismo índice de resistencia estática y amortiguación destructiva que las espumas químicas.
            </p>

            {/* Certifications dynamic hover cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
              {CERTIFICATIONS.map((cert, index) => (
                <div 
                  key={index} 
                  className="p-5 bg-brand-beige-light border border-brand-charcoal/5 rounded-sm shadow-sm transition-all duration-300 hover:border-brand-brown group text-left"
                >
                  <div className="w-10 h-10 bg-brand-brown-light/40 text-brand-brown rounded-full flex items-center justify-center mb-3 group-hover:bg-brand-brown group-hover:text-brand-beige transition-colors duration-300">
                    {cert.title.includes('FSC') ? <TreePine className="w-5 h-5" /> : cert.title.includes('Carbono') ? <Leaf className="w-5 h-5" /> : <Scale className="w-5 h-5" />}
                  </div>
                  <h4 className="font-sans text-xs font-bold text-brand-charcoal uppercase tracking-wider mb-1">
                    {cert.title}
                  </h4>
                  <span className="block font-mono text-[10px] text-brand-brown font-bold mb-2">
                    {cert.code}
                  </span>
                  <p className="font-sans text-[11px] text-brand-sage leading-relaxed">
                    {cert.description}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Right panel: Premium circular Seal Badge visual showcase */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative w-72 h-72 md:w-80 md:h-80 rounded-full border border-brand-olive/15 flex items-center justify-center p-6 bg-brand-beige-container/60">
              
              {/* Spinning Circular Text */}
              <div className="absolute w-full h-full animate-[spin_25s_linear_infinite] p-1 select-none pointer-events-none">
                <svg className="w-full h-full" viewBox="0 0 300 300">
                  <path
                    id="circlePath"
                    d="M 150, 150 m -115, 0 a 115,115 0 1,1 230,0 a 115,115 0 1,1 -230,0"
                    fill="none"
                  />
                  <text className="font-mono text-[9px] fill-brand-olive tracking-[0.25em] font-bold">
                    <textPath href="#circlePath">
                      * MATERIALES BIODEGRADABLES * RIGIDEZ BAJO NORMATIVA INTERNACIONAL * SUSTENTABLE *
                    </textPath>
                  </text>
                </svg>
              </div>

              {/* Central Seal Content holding Playfair Display handwriting callout */}
              <div className="w-48 h-48 rounded-full bg-brand-olive flex flex-col items-center justify-center text-center p-4 shadow-lg relative z-10 border-4 border-brand-beige">
                <span className="font-sans text-[9px] font-extrabold text-brand-beige-light uppercase tracking-widest mb-1">
                  Certificación de
                </span>
                <span className="font-serif italic text-2xl text-brand-brown-light font-normal leading-tight my-1 block">
                  Fibra Pura
                </span>
                <span className="font-mono text-[9px] text-white/70 block mt-1 tracking-wider uppercase">
                  100% Reciclable
                </span>
                <ShieldCheck className="w-6 h-6 text-brand-brown-light mt-2" />
              </div>

            </div>
          </div>

        </div>
      </section>

      {/* Product Catalog Slide Section (Inspired directly by user screenshot) */}
      <ProductCatalog onQuoteRequested={(productTitle) => {
        const text = `Solicitud de cotización rápida sobre: "${productTitle}". Me interesa conocer las especificaciones mínimas de fabricación y costos base para un despacho industrial.`;
        handleApplySpecs(text);
      }} />

      {/* Interactive Estimator / 3D Configurator */}
      <BoxConfigurator onApplySpecs={handleApplySpecs} />

      {/* Core Engineering Workflow Process */}
      <section id="metodo" className="py-24 max-w-7xl mx-auto px-6 relative paper-grain border-t border-brand-charcoal/5">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <span className="font-mono text-xs tracking-widest font-extrabold text-brand-sage uppercase block mb-3">
              Física de Estructuras
            </span>
            <h2 className="font-sans text-3xl md:text-5xl font-extrabold tracking-tight text-brand-charcoal">
              Método de Pruebas Dinámicas
            </h2>
          </div>
          <p className="font-sans text-base text-brand-sage max-w-sm leading-relaxed">
            De la simulación matemática a la distribución final. Minimizamos el factor de error mecánico de forma verificable.
          </p>
        </div>

        {/* Steps Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 text-left">
          {STEPS_WORKFLOW.map((wf, idx) => (
            <div 
              key={idx}
              className="p-6 md:p-8 bg-brand-beige-light border border-brand-charcoal/5 relative rounded-sm group hover:border-brand-olive transition-colors duration-300"
            >
              {/* Step counter layout */}
              <span className="absolute top-4 right-6 font-mono text-xs text-brand-brown font-extrabold">
                {wf.step}
              </span>
              
              <div className="w-10 h-10 rounded-sm bg-brand-beige-container flex items-center justify-center text-brand-olive font-extrabold mb-6 group-hover:bg-brand-olive group-hover:text-brand-beige transition-colors duration-300">
                {idx === 0 ? <Zap className="w-5 h-5" /> : idx === 1 ? <Layers className="w-5 h-5" /> : idx === 2 ? <Scale className="w-5 h-5" /> : <FileText className="w-5 h-5" />}
              </div>

              <h4 className="font-sans text-sm font-extrabold text-brand-charcoal uppercase tracking-wider mb-3">
                {wf.title}
              </h4>

              <p className="font-sans text-xs text-brand-sage leading-relaxed">
                {wf.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Main Dynamic CTA / Contact Form Section */}
      <ContactForm 
        attachedSpecs={attachedSpecs} 
        onClearSpecs={() => setAttachedSpecs('')} 
      />

      {/* Footer Section */}
      <footer className="bg-brand-charcoal text-brand-beige/80 border-t border-brand-olive/10 py-16 paper-grain">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-10 items-start text-left">
          
          {/* Brand info column */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-brand-olive flex items-center justify-center rounded-sm">
                <Layers className="text-brand-beige w-4 h-4" />
              </div>
              <span className="font-sans text-base font-extrabold text-brand-beige tracking-tight uppercase">
                Ingeniería en Papel
              </span>
            </div>
            <p className="font-sans text-xs text-brand-beige/60 leading-relaxed max-w-xs">
              Especialistas en rigidez, volumen troquelado, y resiliencia de flauta para un transporte verde y sin mermas de traslado.
            </p>
          </div>

          {/* Core Menu column */}
          <div>
            <h4 className="font-sans text-xs font-bold text-brand-beige uppercase tracking-widest mb-4">
              Enlaces de Acceso
            </h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button onClick={() => scrollToId('catalogo')} className="text-left text-brand-beige/60 hover:text-white transition-colors cursor-pointer py-1">Catálogo</button>
              <button onClick={() => scrollToId('configurador')} className="text-left text-brand-beige/60 hover:text-white transition-colors cursor-pointer py-1">Simulador 3D</button>
              <button onClick={() => scrollToId('compromiso')} className="text-left text-brand-beige/60 hover:text-white transition-colors cursor-pointer py-1">Sustentabilidad</button>
              <button onClick={() => scrollToId('metodo')} className="text-left text-brand-beige/60 hover:text-white transition-colors cursor-pointer py-1">Método Técnico</button>
            </div>
          </div>

          {/* Email verification and credits */}
          <div className="space-y-4">
            <h4 className="font-sans text-xs font-bold text-brand-beige uppercase tracking-widest">
              Asistencia Directa
            </h4>
            <div className="font-mono text-xs">
              <a href="mailto:jhomardelgado@gmail.com" className="block text-brand-beige-light font-bold hover:underline mb-1">
                jhomardelgado@gmail.com
              </a>
              <span className="text-brand-beige/50 block">Atención: Mon - Fri (8:00 - 18:00 CET)</span>
            </div>
          </div>

        </div>

        {/* Minimal Copyright Bottom Strip */}
        <div className="max-w-7xl mx-auto px-6 mt-12 pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 font-sans text-[10px] text-brand-beige/40">
          <span>
            © 2026 Ingeniería en Papel S.V. Todos los derechos reservados.
          </span>
          <div className="flex gap-4">
            <span>ISO 9001 Homologado</span>
            <span>●</span>
            <span>FSC® Registrado</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
