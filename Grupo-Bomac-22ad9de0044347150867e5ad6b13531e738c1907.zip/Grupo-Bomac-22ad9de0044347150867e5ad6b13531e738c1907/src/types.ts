export interface Product {
  id: string;
  category: string;
  title: string;
  subtitle: string;
  description: string;
  image: string;
  specs: {
    label: string;
    value: string;
  }[];
  certification: string;
  advantages: string[];
}

export interface BoxConfig {
  length: number; // in cm
  width: number;  // in cm
  height: number; // in cm
  cardboardType: 'micro' | 'simple' | 'double' | 'triple';
  quantity: number;
}
