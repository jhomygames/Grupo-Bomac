import { Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: 'carton-corrugado',
    category: 'PRODUCTO INDUSTRIAL',
    title: 'Cartón Corrugado',
    subtitle: 'Resistencia estructural de triple capa para envíos industriales de alta exigencia.',
    description: 'Nuestra solución insignia está engineered para absorber impactos dinámicos gracias a su diseño de flautas optimizadas por computadora. Ideal para el transporte a gran velocidad o almacenamiento prolongado.',
    image: 'https://images.unsplash.com/photo-1607344645866-009c320b63e0?q=80&w=800&auto=format&fit=crop',
    specs: [
      { label: 'Resistencia SCT', value: '44 kN/m' },
      { label: 'Espesor', value: '12.0 mm' },
      { label: 'Biodegradable', value: '100% en 60 días' },
      { label: 'Estibamiento Máx.', value: '2.4 Toneladas' }
    ],
    certification: 'FSC® C124502',
    advantages: [
      'Amortiguación superior asistida',
      'Geometría auto-ensamblable patentada',
      'Cumple normatividad de exportación internacional'
    ]
  },
  {
    id: 'esquineros-reforzados',
    category: 'MINIMIZADOR DE MERMAS',
    title: 'Esquineros de Alta Compresión',
    subtitle: 'Papel Kraft multi-laminado con adhesivos ecológicos resistentes a la compresión vertical.',
    description: 'Componentes estructurales diseñados para maximizar el apilamiento de pallets y evitar el colapso de esquinas bajo tensiones extremas durante el flejado y el transporte marítimo.',
    image: 'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?q=80&w=800&auto=format&fit=crop',
    specs: [
      { label: 'Compresión Lateral', value: '520 kg' },
      { label: 'Laminaciones', value: '18 capas de Kraft' },
      { label: 'Espesores', value: '3.0 mm a 6.0 mm' },
      { label: 'Resistencia al Agua', value: 'Tratamiento hidrófugo' }
    ],
    certification: 'ISO 14001:2015',
    advantages: [
      'Distribución uniforme de presión de fleje',
      'Material 100% reciclable',
      'Dimensióname bajo medida exacta'
    ]
  },
  {
    id: 'papel-kraft-rollos',
    category: 'MÁXIMA VERSATILIDAD',
    title: 'Papel Kraft de Alta Densidad',
    subtitle: 'Solución continua para envoltura protectora y amortiguación de vacíos.',
    description: 'Hojas y rollos industriales de fibra virgen de pino de bosques certificados. Proporciona una barrera fuerte y agradable al tacto con una excelente resistencia al desgarro y punzada.',
    image: 'https://images.unsplash.com/photo-1595079676339-1534801ad6cf?q=80&w=800&auto=format&fit=crop',
    specs: [
      { label: 'Gramaje base', value: '120 g/m² - 200 g/m²' },
      { label: 'Sling Tensile', value: '12.5 kN/m' },
      { label: 'Certificación de Grado', value: 'Alimentario (FDA)' },
      { label: 'Elasticidad (H)', value: '4.2%' }
    ],
    certification: 'FDA & FSC certified',
    advantages: [
      'Acabado ultra-suave anti-abrasión',
      'Rollo con precorte de precisión micro',
      'Zero pigmentación artificial blanqueadora'
    ]
  }
];

export const CERTIFICATIONS = [
  {
    title: 'FSC® Mixto',
    code: 'C124502',
    description: 'Garantía absoluta de que el papel proviene de bosques manejados con estricta responsabilidad social y ambiental.',
    icon: 'TreePine'
  },
  {
    title: 'Carbono Neutral',
    code: 'ISO 14064',
    description: 'Mitigamos y compensamos el 100% de la huella de carbono generada en el proceso de corte y corrugado.',
    icon: 'Leaf'
  },
  {
    title: 'Biodegradabilidad Directa',
    code: 'ASTM D6400',
    description: 'Disolución biológica completa en contacto con tierra orgánica en menos de un ciclo estacional, libre de microplásticos.',
    icon: 'Recycle'
  }
];

export const STEPS_WORKFLOW = [
  {
    step: '01',
    title: 'Análisis de Esfuerzos',
    description: 'Evaluamos las fuerzas de carga estática y dinámica de su cadena de distribución mediante software de simulación física.'
  },
  {
    step: '02',
    title: 'Modelo Geométrico',
    description: 'Cortamos muestras digitales a medida exacta para ensayar ajustes volumétricos óptimos en sus productos.'
  },
  {
    step: '03',
    title: 'Prueba de Esfuerzo Físico',
    description: 'Sometemos los prototipos de prueba a fuerzas de aplastamiento vertical (BCT) y pruebas de caída controladas.'
  },
  {
    step: '04',
    title: 'Suministro Just-in-Time',
    description: 'Entregamos lotes optimizados según su capacidad de almacén para evitar embotellamientos lógicos en planta.'
  }
];
